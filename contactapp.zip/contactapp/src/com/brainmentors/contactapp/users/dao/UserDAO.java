package com.brainmentors.contactapp.users.dao;

public class UserDAO {

}
