package com.brainmentors.contactapp.users.views;

import javax.swing.JFrame;

public class UserView extends JFrame {
	
	
	public UserView(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	
	public static void main(String[] args) {
		new UserView();
		
	
}
}
