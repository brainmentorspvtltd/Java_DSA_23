package JAVA;

import java.util.Locale;

public class CommandLine {
    public static void main(String[] args) {
        // String firstName = args[0];
        // String lastName = args[1];
        // System.out.println("This is the name : " + firstName);
        // System.out.println("This is the name : " + lastName);

        // int i = 0;
        // while (i < 5) {
        // System.out.print("This is JAVA ");
        // i = i++;
        // }

        Locale l = new Locale("hi", "IN");
    }
}
