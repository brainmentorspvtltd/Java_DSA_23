package JAVA;

import java.io.FileNotFoundException;
import java.io.PrintStream;

class SECOND {
    public static void main(String[] args) throws FileNotFoundException {
        // PrintStream out;
        // System.setOut(new
        // PrintStream("C:\\Users\\ACER\\Documents\\RD_JAVA_SEPTEMBER\\code\\Sec
        // B\\JAVA\\secb.txt"));
        System.out.println("JAVA");
    }
}
