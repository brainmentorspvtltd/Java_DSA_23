package JAVA;

class CAR {
    String name;
    String type;

    static CAR obj;

    // this is called default construstor
    private CAR(String name, String type) {
        this.name = name;
        this.type = type;
    }

    static CAR creatObject(String name, String type) {
        if (obj == null) {
            obj = new CAR(name, type);
        }
        return obj;
    }
}

public class SingleTon {

    public static void main(String[] args) {
        // CAR car1 = CAR.creatObject("Fortuner", "SUV");
        // CAR car2 = CAR.creatObject("THAR", "JEEP");
        // CAR car3 = CAR.creatObject("SKODA", "SEDAN");
        // CAR car4 = CAR.creatObject("SWIFT", "HATCHBACK");

        // System.out.println(car3.name);
        // System.out.println(car3.type);

        // String name = "ROHIT";
        // String name4 = "ROHIT";
        // String name2 = name;
        String name3 = new String("ROHIT").intern();
        String name6 = new String("ROHIT").intern();

        System.out.println(name3 == name6);
        // System.out.println(name == name2);
        // System.out.println(name == name3);
    }
    // CAR car1 = new CAR();
    // CAR car2 = new CAR();
    // CAR car3 = new CAR();
    // CAR car4 = new CAR();
    // CAR car5 = new CAR();
}
