package JAVA;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class SalarySlip {

    static void salaryFormat(int val, Locale l) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(l);
        String temp = nf.format(val);
        System.out.println("This is the formatted sal :" + temp);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please select your language");
        System.out.println("Enter 1 for Hindi, 2 for English and 3 for French");
        int langChoice = scanner.nextInt();
        Locale locale;

        if (langChoice == 1) {
            locale = new Locale("hi", "IN");
        } else if (langChoice == 2) {
            locale = new Locale("en", "US");
        } else if (langChoice == 3) {
            locale = new Locale("fr", "FR");
        } else {
            System.out.println("Wrong Choice, now using English as default");
            locale = new Locale("en", "US");
        }

        System.out.println("Please enter your Salary");
        int sal = scanner.nextInt();
        System.out.println("This is the Salary :" + sal);
        salaryFormat(sal, locale);
    }
}
