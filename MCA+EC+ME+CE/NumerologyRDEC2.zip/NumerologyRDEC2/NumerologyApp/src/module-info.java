/**
 * 
 */
/**
 * 
 */
module NumerologyApp {
	requires java.desktop;
}