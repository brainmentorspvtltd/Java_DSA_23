package com.rdec.numerology.constants;

public interface AppConstants {
	int APP_HEIGHT = 200;
	int APP_WIDTH = 900;
	String APP_TITLE = "NUMEROLOGY APP";
}
