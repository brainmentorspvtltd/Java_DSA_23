package com.rdec.numerology.screens;

import javax.swing.JFrame;

import com.rdec.numerology.constants.AppConstants;

public class SplashScreen extends JFrame implements AppConstants {

	public SplashScreen() {

		setSize(APP_WIDTH, APP_HEIGHT);
		setVisible(true);
		setLocationRelativeTo(null);

	}

	public static void main(String[] args) {
		SplashScreen screen = new SplashScreen();

	}

}
