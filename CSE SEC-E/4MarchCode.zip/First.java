package JAVA;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class First {
    public static void main(String[] args) throws FileNotFoundException {
        // PrintStream out = new
        // out.printLn(); 
        System.setOut(new PrintStream("C:\\Users\\ACER\\Documents\\RD_JAVA_SEPTEMBER\\code\\Sec E\\JAVA\\sece.txt"));
        System.out.println("JAVA");
    }
}
