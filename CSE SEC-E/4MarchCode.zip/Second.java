package JAVA;

class ABCD {
    public static void main(String[] args) {
        System.out.println("JAVA");
    }
}