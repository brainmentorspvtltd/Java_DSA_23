package JAVA;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class SalarySlip {

    static void formatSalary(int sal, Locale l) {
        // NumberFormat nf = new NumberFormat();
        NumberFormat nf = NumberFormat.getCurrencyInstance(l);
        String formattedSalary = nf.format(sal);
        System.out.println("This is the formatted salary :" + formattedSalary);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Please select your language");
        System.out.println("Enter 1 for HINDI and 2 for ENGLISH and 3 for FRENCH");
        Locale locale;
        int langChoice = scanner.nextInt();
        if (langChoice == 1) {
            locale = new Locale("hi", "IN");
        } else if (langChoice == 2) {
            locale = new Locale("en", "US");
        } else if (langChoice == 3) {
            locale = new Locale("fr", "FR");
        } else {
            System.out.println("Invalid input, now choosing ENGLISH as Default");
            locale = new Locale("en", "US");
        }
        System.out.println("Please enter your basic salary");
        int sal = scanner.nextInt();
        System.out.println("This is the basic salary :" + sal);
        formatSalary(sal, locale);
    }
}
