package JAVA;

public class Third {
    public static void main(String[] args) {
        String name = "MOHAN";
        String name2 = name;
        String name3 = new String("MOHAN").intern();

        // System.out.println(name == name2);
        System.out.println(name == name3);
    }
}
