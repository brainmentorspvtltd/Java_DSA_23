package com.brainmentors.contactapp.users.dto;

public class UserDTO {
	// Instance Variable
	// default scope (with in the package)
	public String userid;
	public char[] password;

}
