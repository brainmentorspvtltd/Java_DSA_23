package com.brainmentors.contactapp.users.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.brainmentors.contactapp.users.dto.UserDTO;

public class UserDAO {
	Connection con; // null
	public UserDAO(){
		con = createConnection();
	}
	private Connection createConnection() {
		
		// Step-1 Create a Connection to the DataBase
		// Load the Driver, Load the Class
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/contactapp", "root", "amit123456");
		if(con!=null) {
			System.out.println("Connection Created....");
		}
		}
		catch(ClassNotFoundException e) {
			System.out.println(e);
			
		}
		catch(SQLException e) {
			System.out.println(e);
			
		}
		return con;
	}
	
	public static void main(String[] args) {
		UserDAO dao = new UserDAO();
		dao.isRegister(null);
	}
	
	// try catch
	public boolean isRegister(UserDTO userDTO) {
		PreparedStatement pstmt = null;
		try {
		pstmt = con.prepareStatement("insert into users (userid, password) values(?,?)");
		pstmt.setString(1, userDTO.userid);
		pstmt.setString(2, new String(userDTO.password));
		int count = pstmt.executeUpdate();
		
		return count>0;
		}
		catch(SQLException e) {
			System.out.println(e);
			return false;
			
		}
		finally {
			try {
				if(pstmt!=null) {
				pstmt.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public boolean isLogin(UserDTO userDTO) {
		return true;
	}

}
