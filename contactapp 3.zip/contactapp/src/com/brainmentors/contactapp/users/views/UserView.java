package com.brainmentors.contactapp.users.views;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.brainmentors.contactapp.users.dao.UserDAO;
import com.brainmentors.contactapp.users.dto.UserDTO;

//class MyListener implements ActionListener{
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		// Logic
//	}
//}

public class UserView extends JFrame {
	int x; // 0
	// 1. Declare UI Fields
	JTextField userid; // null
	JPasswordField password;
	JLabel useridLbl;
	JLabel passwordLbl;
	JButton loginButton ;
	JButton registerButton;
	
	
	private void doLogin() {
		String useridValue  = userid.getText();
		char[] passwordValue = password.getPassword();
//		System.out.println(useridValue.toString());
//		System.out.println(passwordValue.toString());
		//System.out.println("Login... Call");
	}
	private void doRegister() {
		String useridValue  = userid.getText();
		char[] passwordValue = password.getPassword();
		// fill the data in DTO
		UserDTO userDTO = new UserDTO();
		userDTO.userid = useridValue;
		userDTO.password = passwordValue;
		UserDAO userDAO =new UserDAO();
		boolean result = userDAO.isRegister(userDTO);
		String message = result?"Register SuccessFully":"Problem in Register";
		JOptionPane.showMessageDialog(this, message);
//		System.out.println(useridValue.toString());
//		System.out.println(passwordValue.toString());
		//System.out.println("Login... Call");
	}
	
	private void bindEvents() {
		//loginButton.addActionListener(new MyListener());
		loginButton.addActionListener((e)->doLogin());
		registerButton.addActionListener((e)->doRegister());
	}
	
	private void buildUI() {
		useridLbl = new JLabel("Userid");
		useridLbl.setBounds(100,100,250,50);
		passwordLbl = new JLabel("Password");
		passwordLbl.setBounds(100,200,250,50);
		userid = new JTextField(); // userid has reference
		// 3. Set UI Field Bound 
		userid.setBounds(200,100,250,50);
		password = new JPasswordField();
		password.setBounds(200,200,250,50);
		loginButton = new JButton("Login");
		registerButton= new JButton("Register");
		loginButton.setBounds(150, 300, 100, 50);
		registerButton.setBounds(250, 300, 100, 50);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500,500);
		setLocationRelativeTo(null);
		setLayout(null);
		setResizable(false);
		setTitle("Login / Register");
		// 4. Add UI Field in Frame
		add(useridLbl);
		add(passwordLbl);
		add(userid);
		add(password);
		add(loginButton);
		add(registerButton);
		setVisible(true);
	}
	// Constructor
	public UserView(){
		// 2. UI Object Creation
		buildUI();
		bindEvents();
	}
	
	
	public static void main(String[] args) {
		new UserView(); // Constructor Call
		
	
}
}
