public class TestEmployee {
    public static void main(String[] args) {
        Tri.sin();
        // System s = new System();
        // Tri e = new Tri();
        // e.sin();
        Employee amit = new Employee(1001, "Amit", 2222);
        amit.setSalary(amit.getSalary()+44444);
        amit.print();
        // System.out.println(amit.id);
        // System.out.println(amit.name);
        // System.out.println(amit.salary);
        // int x = 10;
        // amit.id = 101;
        // amit.name=  "Amit";
        // amit.salary = 22222;

        // Employee ram = new Employee();
        // ram.id = 1002;
        // ram.name = "Ram";
        // ram.salary = 2222;

    }
}
