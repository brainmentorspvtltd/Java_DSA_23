import static java.lang.System.out;
import static java.lang.Math.abs;
/*
 * final (fixed) - Can't be change - keyword
 */
//final class Account{
    
     class Account{
    int id;
    String name;
    double balance;
    // final void deposit(){
    //     System.out.println("Account Deposit...");
    // }
     void deposit() throws Exception{
        out.println("Account Deposit...");
    }
}
class SavingAccount extends Account {

    @Override
    protected void deposit() throws IOException{
        super.deposit();
        abs(100);
        System.out.println("SA Deposit");
    }
    void roi(){
        System.out.println("Rec ROI");
    }
}
// IS A
class CurrentAccount extends Account{
    void roi(){
        System.out.println("Pay Roi");
    }
    void odLimit(){
        System.out.println("OD Limit");
    }
}
public class FinalDemo {
    public static void main(String[] args) {
        final int MAX = 100; // Constant
        final SavingAccount sa = new SavingAccount(); // Has-A
        sa.id++;
        sa.deposit();
        sa.roi();
        CurrentAccount ca = new CurrentAccount();
        ca.deposit();
        ca.roi();
        ca.odLimit();
    }    
}
