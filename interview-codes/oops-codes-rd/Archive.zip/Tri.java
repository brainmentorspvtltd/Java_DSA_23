//public class Tri {
    interface Tri{
    // private Tri(){

    // }
    static void sin(){

    }
    static void cos(){

    }
    static void tan(){

    }
}
