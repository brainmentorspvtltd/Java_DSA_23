class A{
    int x, y;
}
public class PassByValuePassByRef {

    static void show(int z){
        z++;
        System.out.println("Z is "+z);
    }
    static void show2(A a ){
        a.x++;
        a.y++;
        System.out.println("X "+a.x);
        System.out.println("Y "+a.y);
    }
    public static void main(String[] args) {
        int y = 100;
        show(y);
        System.out.println("Y is "+y);
        A obj = new A();
        show2(obj);
        System.out.println("X "+obj.x);
        System.out.println("Y "+obj.y);
    }
}
