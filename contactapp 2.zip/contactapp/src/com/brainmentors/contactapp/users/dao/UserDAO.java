package com.brainmentors.contactapp.users.dao;

import com.brainmentors.contactapp.users.dto.UserDTO;

public class UserDAO {
	
	public boolean isRegister(UserDTO userDTO) {
		return true;
	}
	public boolean isLogin(UserDTO userDTO) {
		return true;
	}

}
