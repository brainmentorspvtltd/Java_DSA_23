package com.brainmentors.contactapp.users.dto;

public class UserDTO {
	// Instance Variable
	String userid;
	String password;

}
